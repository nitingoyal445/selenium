import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class OpenWebBrowser {

	private static WebDriver driver;

	public static void main(String[] args) throws InterruptedException {

		ChromeOptions options = new ChromeOptions(); //
		options.addArguments("--disable-popup-blocking");

		driver = new ChromeDriver(options);

		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");

		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		
		PageObjects.openPage(driver);
		
		PageObjects.clickOnSearch(driver).click();
		
		PageObjects.inputInSearch(driver).sendKeys("Google");
		
		PageObjects.clickOnSearchButton(driver).click();

	}
}